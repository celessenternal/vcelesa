local status, bufferline = pcall(require, "bufferline")
if not status then
	return
end

-- Tab pages
bufferline.setup({
	options = {
		buffer_close_icon = "×",
	},
})
