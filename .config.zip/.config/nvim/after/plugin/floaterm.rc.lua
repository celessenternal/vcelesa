local opts = { noremap = true, silent = true }
vim.keymap.set("n", "N", ":FloatermNew<cr>", opts)
