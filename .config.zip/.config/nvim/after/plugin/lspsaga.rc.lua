local status, lspsaga = pcall(require, "lspsaga")
if not status then
	return
end
local opts = { silent = true, noremap = true }
--lspsaga.setup({})

--vim.keymap.set("n", "r", ":Lspsaga rename<cr>", opts)
--vim.keymap.set("n", "ff", ":Lspsaga diagnostic_jump_next<cr>", opts)
--vim.keymap.set("n", "N", ":lspsaga.Lspsaga term_toggle<cr>", opts)
