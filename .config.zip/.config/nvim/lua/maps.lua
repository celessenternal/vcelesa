local keymap = vim.keymap
local opts = { silent = true, noremap = true }

keymap.set("n", "x", '"_x')

keymap.set("n", "+", "<C-a>")
keymap.set("n", "-", "<C-x>")

keymap.set("n", "<C-a>", "ggVG")

keymap.set("n", "te", ":tabedit<Return>", opts)
keymap.set("n", "ss", ":split<Return>", opts)
keymap.set("n", "sv", ":vsplit<Return>", opts)

keymap.set("n", "dw", 'vb"_d')

keymap.set("n", "<Space>", "<C-w>w")
keymap.set("n", "<Tab>", ":tabNext<cr>", opts)
keymap.set("n", "qq", ":q<cr>", opts)
